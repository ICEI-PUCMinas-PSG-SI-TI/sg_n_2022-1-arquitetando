# Divulgação: Apresentação do Projeto

Nesta pasta inclua arquivos de slides que foram produzidos para apresentações do projeto e de seus resultados.

[Apresentação Persona Alvo, Problemas, Objetivos, Possibilidade e Dificuldades.pptx](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/8962096/Apresentacao.Persona.Alvo.Problemas.Objetivos.Possibilidade.e.Dificuldades.pptx)
