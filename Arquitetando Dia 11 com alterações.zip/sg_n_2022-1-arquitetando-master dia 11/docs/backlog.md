| Usuário      | Requisito | Motivação     |
| :----:        |    :----:   |          :----: |
| Como cliente, eu quero      | acessar uma página<br>com informações gerais do produto       | para poder decidir se vou contratar o serviço.   |
| Como usuário, eu quero   | ter acesso privado ao sistema        | para sentir confiança na privacidade<br>de meus dados e pedidos.      |
| Como desenvolvedor, eu preciso | de uma logo | para o reconhecimento da plataforma. |
| Como usuário, eu quero | uma plataforma que ofereça praticidade<br>e simplicidade | para facilitar a cotação de serviços. |
| Como cliente, eu quero | uma pagina inicial | para navegar e criar um cadastro<br>dentro do site. |
| Como usuário, eu quero | uma forma de conferir se o site é confiável | para poder enviar ou receber projetos. |
| Como desenvolvedor, eu quero | uma plataforma bonita, responsiva e eficiente | para atrair mais clientes/usuários. |
| Como desenvolvedor, eu preciso | de uma página inicial e uma<br>página para o cadastro | para iniciar o uso da plataforma<br>pelos clientes/usuários. |
| Como desenvolvedor, eu preciso | de uma área dentro da plataforma destinada<br>aos projetos | para o recibo e o envio destes. | 
| Como desenvolvedor, eu preciso | de um chat dentro da plataforma | para facilitar a interação entre usuários. |
| Como usuário, eu preciso | de uma área específica do site | para avaliação dos prestadores de serviços. |
| Como desenvolvedor, eu preciso | de uma área específica do site | para o portfólio e informações adicionais dos serviços prestados pelos clientes. |
| Como cliente, eu quero | ter uma forma de saber quais empresas prestadoras de serviços estão disponíveis | para poder contratar seus serviços. |
| Como usuário, eu quero | uma plataforma que ofereça a maior quantidade de informações possíveis dos prestadores de serviços | para passar mais confiança na hora de contratar os serviços. |
> Written with [StackEdit](https://stackedit.io/).
