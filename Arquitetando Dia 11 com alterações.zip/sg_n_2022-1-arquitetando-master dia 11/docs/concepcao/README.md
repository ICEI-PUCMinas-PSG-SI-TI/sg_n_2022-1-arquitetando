## Concepção

Inclua aqui os arquivos utilizados no processo de concepção segundo o _design thinking_. (Matriz CSD, mapa de _stakeholders_, personas, mapa de priorização...)

[Matriz CSD e Mapa Stakeholders.pdf](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/8962072/Matriz.CSD.e.Mapa.Stakeholders.pdf)

[Persona Alvo, Problemas, Objetivos, Possibilidade e Dificuldades.pptx](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/8962082/Persona.Alvo.Problemas.Objetivos.Possibilidade.e.Dificuldades.pptx)

[Fomulário de Pesquisa - Entrevista.pdf](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/8962088/Fomulario.de.Pesquisa.-.Entrevista.pdf)

[Pesquisa de Campo - Designer Interiores e Arquiteto.pdf](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/9057095/Pesquisa.de.Campo.-.Designer.Interiores.e.Arquiteto.pdf)

[Pesquisa de Campo - Empresa Planejados.pdf](https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/files/9057097/Pesquisa.de.Campo.-.Empresa.Planejados.pdf)
