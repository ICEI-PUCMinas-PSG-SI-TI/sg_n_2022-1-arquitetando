[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7718806&assignment_repo_type=AssignmentRepo)
# Arquitetando
Criar uma plataforma com o intuito de aproximar arquitetos/designers e empresas de armários planejados
para solicitar cotação de preços e oferecer prestação de serviços.

## Alunos integrantes da equipe

* Ana Paula de Oliveira
* Miguel Henrique Martins Carvalho
* Bruno Silvério Madureira
* Henrique Costa Marques
* Felipe Cardoso

## Professores responsáveis

* João Caram Santos de Oliveira
* Marta Noronha

## Link Kanban
* https://github.com/ICEI-PUCMinas-PSG-SI-TI/sg_n_2022-1-arquitetando/projects/1

